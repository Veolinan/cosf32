const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Dummy user data (for demonstration purposes, replace with a database in a real application)
const users = [
  { username: 'user1', password: 'pass1', email: 'user1@example.com', registrationNumber: '123456' },
  { username: 'Admin', password: 'pass', email: 'admin@example.com', registrationNumber: '12admin' },
  // Add more users as needed
];

// Nodemailer configurationv
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com',
    pass: 'your-email-password',
  },
});

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/login.html');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    res.sendFile(__dirname + '/public/contact-form.html');
  } else {
    res.send('Invalid login credentials');
  }
});

app.post('/search-contact', (req, res) => {
  const { regNumber } = req.body;

  // Search for contact by registration number
  const contact = users.find(u => u.registrationNumber === regNumber);

  if (contact) {
    // Found the contact
    res.send(`
      <h2>Contact Details:</h2>
      <p>Username: ${contact.username}</p>
      <p>Email: ${contact.email}</p>
      <p>Registration Number: ${contact.registrationNumber}</p>
    `);
  } else {
    // Contact not found
    res.send('<h2>Contact not found</h2>');
  }
});

app.post('/forgot-password', (req, res) => {
  const { email } = req.body;
  const user = users.find(u => u.email === email);

  if (user) {
    // Generate a random password (you may want to use a more secure method)
    const newPassword = Math.random().toString(36).slice(-8);

    // Update user's password (this is just for demonstration, in a real app, you would hash the password)
    user.password = newPassword;

    // Send password reset email
    const mailOptions = {
      from: 'your-email@gmail.com',
      to: email,
      subject: 'Password Reset',
      text: `Your new password: ${newPassword}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        res.send('Error sending email');
      } else {
        console.log('Email sent: ' + info.response);
        res.send('Password reset email sent');
      }
    });
  } else {
    res.send('User not found');
  }
});

//code for handling contact form submission and searching for contacts by registration number
app.post('/submit-contact', (req, res) => {
  const { phone, email, address, regNumber } = req.body;

  // Here you can do something with the submitted contact details
  // For now, let's just log them
  console.log('Submitted Contact Details:');
  console.log('Phone:', phone);
  console.log('Email:', email);
  console.log('Address:', address);
  console.log('Registration Number:', regNumber);

  // You might want to save these details to a database in a real application

  res.send('Contact details submitted successfully');
});

app.post('/search-contact', (req, res) => {
  const { regNumber } = req.body;

  // Search for contact by registration number
  const contact = users.find(u => u.registrationNumber === regNumber);

  if (contact) {
    // Found the contact
    res.send(`Contact Details:\nPhone: ${contact.phone}\nEmail: ${contact.email}\nAddress: ${contact.address}`);
  } else {
    // Contact not found
    res.send('Contact not found');
  }
});


app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
